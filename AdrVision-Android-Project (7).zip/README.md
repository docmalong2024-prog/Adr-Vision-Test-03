# 🚀 ADR Vision - by ductri (Zalo: 0826130621)
## INNOVATING PERSPECTIVES - Real-time Object Tracking & Math Vision AI Solver

Ứng dụng Android Native CameraX + ML Kit: Tự động quét bề mặt vở/sách/màn hình để nhận diện bài toán & cho đáp án siêu tốc, kết hợp nhận diện vật thể thời gian thực 60 FPS.

- **Tác giả:** ductri
- **Hotline / Zalo hỗ trợ kỹ thuật:** 0826130621

---

## 📱 CÁCH TẠO FILE APK CÀI ĐẶT TRỰC TIẾP:

### Cách 1: Tự động xuất APK qua GitHub Actions (Khuyên dùng)
1. Đẩy mã nguồn lên GitHub.
2. File workflow `.github/workflows/build-apk.yml` đã được cấu hình sẵn.
3. Vào tab **Actions** trên GitHub ➔ Đợi 2 phút ➔ Tải tệp **`AdrVision-app-debug`** về điện thoại.

### Cách 2: Mở bằng Android Studio
1. Mở Android Studio ➔ Chọn **Open** ➔ Chọn thư mục dự án này.
2. Nhấn **Run (Shift + F10)** để cài trực tiếp vào điện thoại.
