package com.adrvision.app.presentation

import androidx.camera.core.CameraSelector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adrvision.app.domain.model.DetectedObjectUI
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Trạng thái UI (UiState) cho màn hình Vision
 */
data class VisionUiState(
    val isTrackingActive: Boolean = true,
    val lensFacing: Int = CameraSelector.LENS_FACING_BACK,
    val fps: Int = 0,
    val inferenceTimeMs: Long = 0L,
    val detectedObjects: List<DetectedObjectUI> = emptyList(),
    val confidenceThreshold: Float = 0.5f
)

/**
 * ViewModel chịu trách nhiệm quản lý state và logic điều khiển của Adr Vision.
 */
class VisionViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(VisionUiState())
    val uiState: StateFlow<VisionUiState> = _uiState.asStateFlow()

    // Bộ tính toán FPS (Frames Per Second) mượt mà
    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()

    /**
     * Cập nhật danh sách vật thể được phát hiện từ ObjectDetectorAnalyzer
     */
    fun onObjectsDetected(objects: List<DetectedObjectUI>, inferenceTime: Long) {
        if (!_uiState.value.isTrackingActive) return

        calculateFps()

        _uiState.update { current ->
            current.copy(
                detectedObjects = objects.filter { it.confidence >= current.confidenceThreshold },
                inferenceTimeMs = inferenceTime
            )
        }
    }

    /**
     * Bật/Tắt chế độ theo dõi vật thể (Pause / Resume Tracking)
     */
    fun toggleTracking() {
        _uiState.update { current ->
            val newState = !current.isTrackingActive
            current.copy(
                isTrackingActive = newState,
                detectedObjects = if (!newState) emptyList() else current.detectedObjects
            )
        }
    }

    /**
     * Chuyển đổi giữa Camera Trước (Front) và Camera Sau (Back)
     */
    fun toggleCameraLens() {
        _uiState.update { current ->
            val newLens = if (current.lensFacing == CameraSelector.LENS_FACING_BACK) {
                CameraSelector.LENS_FACING_FRONT
            } else {
                CameraSelector.LENS_FACING_BACK
            }
            current.copy(
                lensFacing = newLens,
                detectedObjects = emptyList() // Xóa cache vật thể cũ khi đổi camera
            )
        }
    }

    /**
     * Điều chỉnh ngưỡng độ tự tin (Confidence Threshold)
     */
    fun setConfidenceThreshold(threshold: Float) {
        _uiState.update { it.copy(confidenceThreshold = threshold) }
    }

    /**
     * Thuật toán đo FPS thực tế của pipeline AI
     */
    private fun calculateFps() {
        frameCount++
        val currentTime = System.currentTimeMillis()
        val elapsed = currentTime - lastFpsTimestamp
        if (elapsed >= 1000L) {
            val currentFps = (frameCount * 1000L / elapsed).toInt()
            _uiState.update { it.copy(fps = currentFps) }
            frameCount = 0
            lastFpsTimestamp = currentTime
        }
    }
}