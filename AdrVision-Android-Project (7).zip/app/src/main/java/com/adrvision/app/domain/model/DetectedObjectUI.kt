package com.adrvision.app.domain.model

import android.graphics.RectF

/**
 * Data class biểu diễn thông tin vật thể được AI nhận diện
 * @param trackingId ID định danh theo dõi vật thể qua các khung hình liên tiếp (Tracking ID)
 * @param label Tên nhãn của vật thể (Người, Xe, Đồ vật...)
 * @param confidence Điểm độ tự tin dự đoán (0.0f - 1.0f)
 * @param normalizedBoundingBox Tọa độ chữ nhật chuẩn hóa [0..1] để vẽ Canvas
 */
data class DetectedObjectUI(
    val trackingId: Int? = null,
    val label: String,
    val confidence: Float,
    val normalizedBoundingBox: RectF
)