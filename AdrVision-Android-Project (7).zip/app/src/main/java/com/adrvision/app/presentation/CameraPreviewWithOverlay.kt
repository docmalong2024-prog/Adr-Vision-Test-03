package com.adrvision.app.presentation

import android.util.Size
import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size as ComposeSize
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.adrvision.app.domain.model.DetectedObjectUI
import com.adrvision.app.ml.ObjectDetectorAnalyzer
import java.util.concurrent.Executors

/**
 * Màn hình giao diện chính của Adr Vision: Camera Preview + Compose Overlay + Bảng điều khiển
 */
@Composable
fun VisionScreen(
    viewModel: VisionViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Executor riêng cho việc phân tích hình ảnh AI để không chiếm dụng Main Thread
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        // 1. Khung hiển thị Camera Preview gốc từ CameraX
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()

                    // Cấu hình UseCase Preview
                    val preview = Preview.Builder()
                        .setTargetResolution(Size(1280, 720))
                        .build()
                        .also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                    // Cấu hình UseCase ImageAnalysis với chiến lược STRATEGY_KEEP_ONLY_LATEST
                    // để giảm thiểu độ trễ tối đa (chỉ xử lý frame mới nhất)
                    val imageAnalyzer = ImageAnalysis.Builder()
                        .setTargetResolution(Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                        .build()
                        .also { analysis ->
                            analysis.setAnalyzer(
                                cameraExecutor,
                                ObjectDetectorAnalyzer { objects, inferenceTime ->
                                    viewModel.onObjectsDetected(objects, inferenceTime)
                                }
                            )
                        }

                    val cameraSelector = CameraSelector.Builder()
                        .requireLensFacing(uiState.lensFacing)
                        .build()

                    try {
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalyzer
                        )
                    } catch (exc: Exception) {
                        exc.printStackTrace()
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            update = { /* Rebind nếu cần đổi lens facing */ }
        )

        // 2. Lớp phủ Canvas vẽ Bounding Boxes và Labels theo thời gian thực
        ObjectBoundingBoxOverlay(
            detectedObjects = uiState.detectedObjects,
            isTrackingActive = uiState.isTrackingActive,
            modifier = Modifier.fillMaxSize()
        )

        // 3. Thanh trạng thái HUD trên cùng (FPS, Thời gian suy luận, Số lượng vật thể)
        TopStatusBar(
            fps = uiState.fps,
            inferenceTimeMs = uiState.inferenceTimeMs,
            objectCount = uiState.detectedObjects.size,
            isTracking = uiState.isTrackingActive,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(16.dp)
        )

        // 4. Bảng điều khiển phía dưới (Chuyển camera, Tạm dừng/Tiếp tục theo dõi)
        BottomControlBar(
            isTrackingActive = uiState.isTrackingActive,
            onToggleTracking = { viewModel.toggleTracking() },
            onToggleCamera = { viewModel.toggleCameraLens() },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(20.dp)
        )
    }
}

/**
 * Lớp vẽ Canvas: Vẽ các hộp Bounding Box với màu sắc công nghệ neon và góc viền đẹp mắt
 */
@Composable
fun ObjectBoundingBoxOverlay(
    detectedObjects: List<DetectedObjectUI>,
    isTrackingActive: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (!isTrackingActive) return@Canvas

        val canvasWidth = size.width
        val canvasHeight = size.height

        detectedObjects.forEach { obj ->
            val rect = obj.normalizedBoundingBox
            val left = rect.left * canvasWidth
            val top = rect.top * canvasHeight
            val right = rect.right * canvasWidth
            val bottom = rect.bottom * canvasHeight
            val width = right - left
            val height = bottom - top

            val primaryColor = Color(0xFF00E5FF) // Màu Cyan Cyberpunk
            val cornerLength = 24.dp.toPx()
            val strokeWidth = 3.dp.toPx()

            // 1. Vẽ khung chữ nhật mờ nền
            drawRoundRect(
                color = primaryColor.copy(alpha = 0.12f),
                topLeft = Offset(left, top),
                size = ComposeSize(width, height),
                cornerRadius = CornerRadius(8.dp.toPx())
            )

            // 2. Vẽ viền nét đứt nhẹ quanh hộp
            drawRoundRect(
                color = primaryColor.copy(alpha = 0.5f),
                topLeft = Offset(left, top),
                size = ComposeSize(width, height),
                cornerRadius = CornerRadius(8.dp.toPx()),
                style = Stroke(
                    width = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                )
            )

            // 3. Vẽ 4 góc nhấn mạnh (Targeting Corner Accents)
            // Góc trên-trái
            drawLine(primaryColor, Offset(left, top), Offset(left + cornerLength, top), strokeWidth)
            drawLine(primaryColor, Offset(left, top), Offset(left, top + cornerLength), strokeWidth)

            // Góc trên-phải
            drawLine(primaryColor, Offset(right, top), Offset(right - cornerLength, top), strokeWidth)
            drawLine(primaryColor, Offset(right, top), Offset(right, top + cornerLength), strokeWidth)

            // Góc dưới-trái
            drawLine(primaryColor, Offset(left, bottom), Offset(left + cornerLength, bottom), strokeWidth)
            drawLine(primaryColor, Offset(left, bottom), Offset(left, bottom - cornerLength), strokeWidth)

            // Góc dưới-phải
            drawLine(primaryColor, Offset(right, bottom), Offset(right - cornerLength, bottom), strokeWidth)
            drawLine(primaryColor, Offset(right, bottom), Offset(right, bottom - cornerLength), strokeWidth)

            // 4. Vẽ nhãn Label + Tracking ID + Độ tự tin
            val labelText = "${obj.label} ${(obj.confidence * 100).toInt()}%" +
                    (if (obj.trackingId != null) " [ID:${obj.trackingId}]" else "")

            drawContext.canvas.nativeCanvas.apply {
                val textPaint = android.graphics.Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 34f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    isAntiAlias = true
                }
                val bgPaint = android.graphics.Paint().apply {
                    color = android.graphics.Color.argb(220, 0, 160, 200)
                    isAntiAlias = true
                }

                val textBounds = android.graphics.Rect()
                textPaint.getTextBounds(labelText, 0, labelText.length, textBounds)

                val tagLeft = left
                val tagTop = (top - 46f).coerceAtLeast(10f)
                val tagRight = tagLeft + textBounds.width() + 32f
                val tagBottom = tagTop + textBounds.height() + 24f

                drawRoundRect(
                    android.graphics.RectF(tagLeft, tagTop, tagRight, tagBottom),
                    12f, 12f, bgPaint
                )
                drawText(
                    labelText,
                    tagLeft + 16f,
                    tagBottom - 12f,
                    textPaint
                )
            }
        }
    }
}

/**
 * Thanh HUD hiển thị thông số hiệu năng
 */
@Composable
fun TopStatusBar(
    fps: Int,
    inferenceTimeMs: Long,
    objectCount: Int,
    isTracking: Boolean,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xCC111827))
            .border(1.dp, Color(0xFF374151), RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "Adr Vision Live",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isTracking) Color(0xFF10B981) else Color(0xFFEF4444))
                )
                Text(
                    text = if (isTracking) "Đang theo dõi" else "Tạm dừng",
                    fontSize = 12.sp,
                    color = Color.LightGray
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            StatPill(label = "FPS", value = "$fps", color = Color(0xFF00E5FF))
            StatPill(label = "Latency", value = "${inferenceTimeMs}ms", color = Color(0xFFA78BFA))
            StatPill(label = "Objects", value = "$objectCount", color = Color(0xFF34D399))
        }
    }
}

@Composable
fun StatPill(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 10.sp, color = Color.Gray)
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

/**
 * Thanh công cụ điều khiển phía dưới màn hình
 */
@Composable
fun BottomControlBar(
    isTrackingActive: Boolean,
    onToggleTracking: () -> Unit,
    onToggleCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xCC000000))
            .border(1.dp, Color(0xFF1F2937), RoundedCornerShape(24.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Nút Đổi Camera trước / sau
        IconButton(
            onClick = onToggleCamera,
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Color(0xFF1F2937))
        ) {
            Icon(
                imageVector = Icons.Filled.Cameraswitch,
                contentDescription = "Chuyển Camera",
                tint = Color.White
            )
        }

        // Nút Pause / Resume Tracking chính giữa
        Button(
            onClick = onToggleTracking,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isTrackingActive) Color(0xFFEF4444) else Color(0xFF10B981)
            ),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Icon(
                imageVector = if (isTrackingActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isTrackingActive) "Tạm dừng AI" else "Tiếp tục quét",
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }
    }
}